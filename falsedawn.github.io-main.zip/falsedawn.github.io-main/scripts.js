$( function() {
  $( "#menu" ).menu();
} );